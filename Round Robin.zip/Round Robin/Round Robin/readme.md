CPU Scheduler

This program simulates an operating system. Processes are added to a ready que, if there are processes in the ready que, the ready que will run each process on CPU for the set timesplice. When the timesplice is over, if the process is not completed, it will be removed from its running state on the CPU and put back into the last position of the Ready Que. The next first item in the ready que is then selected to run on CPU. This repeats until there are no more processes in the running que.

Potential Implementations:
- A GUI Graph
- IO Cycles and Device Ques

Version 0.7: Adding scheduling calculations
![alt tag](https://image.ibb.co/mOtSHc/CPUSched.png)

Version 0.1: Getting GUI up and running
             Process, Task, CPU, Ready Que objects created and
             tested in live simulation.
![alt tag](https://image.ibb.co/iun9Vx/CPUSched2.png)
