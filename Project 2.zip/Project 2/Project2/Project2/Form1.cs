﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project2
{
    public partial class Form1 : Form
    {
        StreamWriter storeInfo1;
        StreamWriter storeInfo2;
        String File1="";
        String File2="";
        String Word = "";
        String line;

        String toString1="";
        String toString2="";
        bool firsrecord = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            String[] Recorddata = new string[3];
            String info="";

            //getting the user's word
            Word = textBox1.Text;
            
            try
            {
                openFileDialog1.InitialDirectory = @"C:\Users\Mcdonald\Desktop\Project 2";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    using (StreamReader getFile = new StreamReader(openFileDialog1.FileName))
                    {

                        textBox2.Clear();

                        while((line=getFile.ReadLine())!=null)
                        {
                            Recorddata = info.Split('|');

                            String File1 = ("          User's word : "+ Word + Environment.NewLine+"  Text file 1 :    a :  " + line.Substring(0, line.IndexOf('|')) + ", b :  "
                                + line.Split('|').Skip(1).FirstOrDefault()) + ", c :   " + line.Split('|').Skip(2).FirstOrDefault();

                            toString1 = File1;
                            
                            textBox2.AppendText(toString1);
                            
                        }
                        
                    }
                }

            }
            catch (Exception exc)
            {
                MessageBox.Show("No file was written,please try again...\n " + exc.Message);
                

            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try

            {
                if (firsrecord)
                {

                    saveFileDialog1.InitialDirectory = @"C:\Users\Mcdonald\Desktop\Project 2";
                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                        firsrecord = false;

                }
                using (storeInfo1 = new StreamWriter(saveFileDialog1.FileName, true))
                {
                    
                    //Writing to texfile 3
                    
                    if(File.Exists(saveFileDialog1.FileName))
                    {
                        Word = textBox2.Text;
                        storeInfo1.WriteLine(File1);
                        storeInfo1.WriteLine(File2);
                        storeInfo1.WriteLine(textBox2.Text);

                        storeInfo1.Close();
                    }

                    
                }
           
    
            }
            catch (Exception exc)
            {
                MessageBox.Show("No file was written,please try again...\n "+exc.Message);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String[] Recorddata = new string[3];
            String info = "";

            //getting the user's word
            Word = textBox1.Text;

            try
            {
                
                openFileDialog1.InitialDirectory = @"C:\Users\Mcdonald\Desktop\Project 2";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    using (StreamReader getFile = new StreamReader(openFileDialog1.FileName))
                    {
                        
                        while ((line = getFile.ReadLine()) != null)
                        {
                            Recorddata = info.Split('|');

                            String File2 = ("Text file 2 : a :  "+ line.Substring(0, line.IndexOf('|')) + ", b :  "
                                + line.Split('|').Skip(1).FirstOrDefault()) + ", c :   " + line.Split('|').Skip(2).FirstOrDefault();
                            
                            toString2 = File2;
                            
                            textBox2.AppendText(Environment.NewLine+toString2);
                            

                        }

                    }
                }

            }
            catch (Exception exc)
            {
                MessageBox.Show("No file was written,please try again...\n " + exc.Message);
                

            }


        }
    }
}
